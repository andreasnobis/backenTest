<?php

namespace MyFirstViewTest\Providers;


use Plenty\Plugin\ServiceProvider;

    class MyFirstViewServiceProvider extends ServiceProvider
    {
        public function register()
        {
          
        }
    }
