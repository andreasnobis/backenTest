# Release Notes for MyFirstView plugin
 
## v1.0.1 (2017-01-16)
 
### Added
- Added files to fulfil plugin requirements for plentyMarketplace
- Added `changelog_en.md`
- Added `changelog_de.md`
- Added `user_guide_en.md`
- Added `user_guide_de.md`
- Added icons and images in the **meta** folder

### Changed
- Changed `plugin.json` to comply with plugin requirements for plentyMarketplace
 
## v1.0.0 (2017-01-16)
 
### Added
- Added initial plugin files