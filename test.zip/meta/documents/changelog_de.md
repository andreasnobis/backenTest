# Release Notes für MyFirstView Plugin
 
## v1.0.1 (2017-01-16)
 
### Hinzugefügt
Dateien hinzugefügt, um die Plugin-Anforderungen des plentyMarketplace zu erfüllen:

- `changelog_en.md`  hinzugefügt
- `changelog_de.md`  hinzugefügt
- `user_guide_en.md` hinzugefügt
- `user_guide_de.md` hinzugefügt
- Icons und Bilder im **meta**-Ordner hinzugefügt

### Geändert
- `plugin.json` geändert, damit diese die Plugin-Anforderungen des plentyMarketplace erfüllt
 
## v1.0.0 (2017-01-16)
 
### Hinzugefügt
- Initiale Plugin-Dateien hinzugefügt